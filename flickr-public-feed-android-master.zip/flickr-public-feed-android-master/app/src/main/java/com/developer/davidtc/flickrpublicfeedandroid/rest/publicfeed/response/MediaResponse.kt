package com.developer.davidtc.flickrpublicfeedandroid.rest.publicfeed.response

/**
 * Created by david.tiago on 11/26/17.
 */
data class MediaResponse (val m: String)